package com.worksheet.java;

import java.util.Scanner;

public class FindVowel {

	   public static void main(String args[]) 
	   {
		   boolean counter= false;
		   System.out.println("Enter the String :");
		   Scanner sc= new Scanner(System.in);
	      String str = sc.nextLine();
	      for(int i=0; i<str.length(); i++) 
	      {
	         if(str.charAt(i) == 'a'|| str.charAt(i) == 'e'|| str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u') 
	         {
	        	   //System.out.println("Given string has a vowel");
	        	   counter= true;
	        	   break;
	         }
	         	
	      }
	      if (counter ==true)
	      {
	    	  System.out.println("Given string has a vowel");
	      }else
	    	  
	    	  System.out.println("Given string doesn't have a vowel");
      	
	      
	   }
	}