package com.worksheet.java;

import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
public class Arraylist {
	public static void main(String[] args) {
		ArrayList<Integer> numbers= new ArrayList<>(Arrays.asList(1,2,34,2,4,6,4,87,34,90,5,2,56,87));
		System.out.println("ArrayList with duplicate numbers :"+numbers);
		 Set<Integer> set =new LinkedHashSet<>();
		 set.addAll(numbers);
		 
		 numbers.clear();
		 
		 numbers.addAll(set);
		 System.out.println("ArrayList after removing duplicates :"+numbers);
		 
	}

}
