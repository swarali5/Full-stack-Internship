package com.worksheet.java;

public class LinkedList {
    
    Node head;    
    class Node
    {
        int data;
        Node next;
        Node(int d)
        {
            data = d;
            next = null;
        }
    }
 
    void getUnion(Node head1,
                  Node head2)
    {
        Node t1 = head1, t2 = head2;
      
        while (t1 != null)
        {
            push(t1.data);
            t1 = t1.next;
        }
 
        while (t2 != null)
        {
            if (!isPresent(head, t2.data))
                push(t2.data);
            t2 = t2.next;
        }
    }
 
    void getIntersection(Node head1,
                         Node head2)
    {
        Node result = null;
        Node t1 = head1;
 
        
        while (t1 != null)
        {
            if (isPresent(head2, t1.data))
                push(t1.data);
            t1 = t1.next;
        }
    }
 
    
    void printList()
    {
        Node temp = head;
        while (temp != null)
        {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
 
    /*  Inserts a node at start of
        linked list */
    void push(int newdata)
    {
        
        Node newnode = new Node(newdata);
 
        
        newnode.next = head;
 
        head = newnode;
    }
 
    boolean isPresent(Node head, int data)
    {
        Node t = head;
        while (t != null) {
            if (t.data == data)
                return true;
            t = t.next;
        }
        return false;
    }
 
    
    public static void main(String args[])
    {
        LinkedList llist1 = new LinkedList();
        LinkedList llist2 = new LinkedList();
        LinkedList union = new LinkedList();
        LinkedList intersection = new LinkedList();
 
        llist1.push(10);
        llist1.push(14);
        llist1.push(35);
        llist1.push(7);
        llist1.push(67);
        llist1.push(80);
 
        llist2.push(14);
        llist2.push(2);
        llist2.push(7);
        llist2.push(80);
        llist2.push(89);
 
        intersection.getIntersection(llist1.head,
                                  llist2.head);
        union.getUnion(llist1.head, llist2.head);
 
        System.out.println("First List is");
        llist1.printList();
 
        System.out.println("Second List is");
        llist2.printList();
        
        System.out.println("Union List is");
        union.printList();

        System.out.println("Intersection List is");
        intersection.printList();
 
    }
}