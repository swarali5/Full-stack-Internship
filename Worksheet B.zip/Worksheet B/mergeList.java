package com.worksheet.java;

 class ListNode {
 
    int val;
    ListNode next;
 
    ListNode() {}
    ListNode(int val) { this.val = val; }
 
    ListNode(int val, ListNode next)
    {
        this.val = val;
        this.next = next;
    }
}
 
public class mergeList {
 
    public static ListNode mergeTwoLists(ListNode l1,
                                         ListNode l2)
    {
 
        
        ListNode result = null;
 
       
        if (l1 == null) {
            return l2;
        }
        else if (l2 == null) {
            return l1;
        }
 
        
        if (l1.val <= l2.val) {
            result = l1;
            result.next = mergeTwoLists(l1.next, l2);
        }
        else {
            result = l2;
            result.next = mergeTwoLists(l1, l2.next);
        }
        return (result);
    }
    
    static void printList(ListNode node)
    {
        while (node != null) {
            System.out.print(node.val + " ");
            node = node.next;
        }
    }
 
    
    public static void main(String[] args)
    {
        ListNode head1 = new ListNode(23);
        head1.next = new ListNode(35);
        head1.next.next = new ListNode(65);
        System.out.println("first list is :");
        printList(head1);
 
        
        ListNode head2 = new ListNode(43);
        head2.next = new ListNode(59);
        head2.next.next = new ListNode(60);
 
        System.out.println("\nSecond list is :");
        printList(head2);
        
        ListNode mergedhead = mergeTwoLists(head1, head2);
 
        System.out.println("\nMerged List is : ");
        printList(mergedhead);
    }
}