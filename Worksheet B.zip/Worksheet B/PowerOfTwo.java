package com.worksheet.java;
import java.util.Scanner;
public class PowerOfTwo {


static boolean isPowerOfTwo(int n)
{
    if (n == 0)
        return false;

    while (n != 1) {
        if (n % 2 != 0)
            return false;
        n = n / 2;
        //return true;
    }
    return true;
}

// Driver program
public static void main(String args[])
{
	System.out.println("Enter the Number :");
	Scanner sc= new Scanner(System.in);
	int num =sc.nextInt();
	
    if (isPowerOfTwo(num)== true)
        System.out.println("Yes..Number is a power of two");
    else
        System.out.println("No..Number is not a power of two");

    
}
}