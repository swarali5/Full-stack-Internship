package com.worksheet.java;

import java.util.Scanner;

public class HappyNumber {
    public static int isNumHappy(int num) {
        int rem = 0, sum = 0;
        // calculate the sum of squares of each digit
        while (num > 0) {
            rem = num % 10;
            sum = sum + (rem * rem);
            num = num / 10;
        }
        return sum;
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number greater than 0:");
        int val = sc.nextInt();
        
        while (val != 1 && val != 4) {
            val = isNumHappy(val);
        }
        if (val == 1) {
            System.out.println("The number entered is a Happy Number");
        } else {
            System.out.println(" The number entered is not a Happy Number");
        }
    }
}