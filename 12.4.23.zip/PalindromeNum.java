package com.worksheet.java;

import java.util.Scanner;

public class PalindromeNum {
  
	 public static void main(String args[]){  
	  int r,sum=0,temp;    
	  System.out.println("ENter the Number to check : ");
	  Scanner sc = new Scanner(System.in);
	  int n= sc.nextInt();
	  temp=n; //saving the number value in temp variable to check the palindrome or not  
	  
	  while(n>0){    
	   r=n%10;  //calculate the reminder
	   sum=(sum*10)+r;   //reverse the number and stored the value in sum variable
	   n=n/10;    
	  }   
	  
	  if(temp==sum)    
	   System.out.println("It's a palindrome Number ");    
	  else    
	   System.out.println("It's not palindrome Number");    
	}  
	}