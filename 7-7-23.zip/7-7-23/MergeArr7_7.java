package com.DailyAssignment.java;

import java.util.Arrays;
import java.util.Scanner;

public class MergeArr7_7 {
	static void merge( long arr1[],  long arr2[], int n, int m) 
    {
		int x =  n-1; //declaring length of first array
		int y = 0;
    
    while(x>=0 && y<m) //swap numbers in ascending order till length of array1
    {
        if(arr1[x] > arr2[y]){
            long temp = arr1[x];
            arr1[x] = arr2[y];
            arr2[y] = temp;
            x--; //decrease the lenght
            y++;//increase in count
        }
        else{
            break;
        }
    }
    
    Arrays.sort(arr1); //sort array1
    Arrays.sort(arr2);//sort array2
    System.out.println("array 1 :"); //print arr1
    for(int i=0;i<n;i++)
	{
		System.out.print(arr1[i]+" ");
	}
    System.out.println("\n\nArray 2 :"); //print arr2
    for(int i=0;i<m;i++)
	{
		System.out.print(arr2[i]+" ");
	}


     }

	
    public static void main(String[] args) {
    	System.out.println("Enter the lenghth of an array 1 :");
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		
		System.out.println("Enter the array elements :");
		long[] arr1=new long[n];
		//take array elements from user
		for(int i=0;i<n;i++)
		{
			arr1[i]=sc.nextInt();
		}
		System.out.println("Enter the lenghth of an array 2 :");
	
		int m= sc.nextInt();
		
		System.out.println("Enter the array elements :");
		long[] arr2=new long[m];
		//take array elements from user
		for(int i=0;i<m;i++)
		{
			arr2[i]=sc.nextInt();
		}
		merge(arr1,arr2,n,m); //function call
	}
}
