package com.DailyAssignment.java;

public class MaxPathTree7_7 {
	//node
	static class treeNode 
	 {
	    int data;
	    treeNode left, right;
	 
	    treeNode(int item) {
	        data = item;
	        left = right = null;
	    }
	}
	 
	// An object of Res is passed around so that the
	// same value can be used by multiple recursive calls.
	class Res {
	    int val;
	}
	 
	
	  treeNode root;
	 
	    //function to find the maximum sum between any
	    // two leaves..
	    
	    int maxPathSumUtil(treeNode node, Res res) {
	 
	        // Base cases
	        if (node == null)
	            return 0;
	        if (node.left == null && node.right == null)
	            return node.data;//  The maximum root to leaf path sum which is returned.
	 
	        // Find maximum sum in left and right subtree. Also
	        
	        int ls = maxPathSumUtil(node.left, res);
	        int rs = maxPathSumUtil(node.right, res);
	 
	        // If both left and right children exist
	        if (node.left != null && node.right != null) {
	 
	            // Update result if needed
	            res.val = Math.max(res.val, ls + rs + node.data);
	 
	            // Return maximum possible value for root being  on one side
	            return Math.max(ls, rs) + node.data;
	        }
	 
	        // If any of the two children is empty, return root sum for root being on one side
	        return (node.left == null) ? rs + node.data : ls + node.data;
	    }
	 
	    //  function which returns sum of the maximum sum path between two leaves. 
	    int maxPathSum() {
	        Res res = new Res();
	        res.val = Integer.MIN_VALUE;
	 
	        int val = maxPathSumUtil(root, res);
	       
	        if (root.left != null && root.right != null)
	            return res.val;
	        else {
	               
	              return Math.max(res.val,val);
	        }
	    }
	 
	    
	    public static void main(String args[]) {
	    	MaxPathTree7_7 tree = new MaxPathTree7_7(); //taking the input from user
	    	
	        tree.root = new treeNode(-15);
	        tree.root.left = new treeNode(5);
	        tree.root.right = new treeNode(6);
	        tree.root.left.left = new treeNode(-8);
	        tree.root.left.right = new treeNode(1);
	        tree.root.left.left.left = new treeNode(2);
	        tree.root.left.left.right = new treeNode(6);
	        tree.root.right.left = new treeNode(3);
	        tree.root.right.right = new treeNode(9);
	        tree.root.right.right.right = new treeNode(0);
	        tree.root.right.right.right.left = new treeNode(4);
	        tree.root.right.right.right.right = new treeNode(-1);
	        tree.root.right.right.right.right.left = new treeNode(10);
	     
	        System.out.println("Max pathSum of the given binary tree is "
	                + tree.maxPathSum()); //function call
	    }
	}
	 

