package com.DailyAssignment.java;

import java.util.Scanner;
public class TrailingZeros 
{
// a method that computes the factorial of the number num  
	public long findFactorial(int num)  
	{  
		long ans = 1;  
		for(int i = 2; i <= num; i++)  
		{  
			ans = ans * i;  
		}  
		return ans;  
	}  
  
  
// a method that counts the number of trailing zeros in the number num  
	public int findCountTrailingZeros(long num)  
	{  
		int cntTrailingZeros = 0; // a variable that stores the trailing zeros number that is present in the number num  
 
		while(true)  
		{  
			// if the remainder is zero when we divide the number num is zero. It means there is a trailing zero in the number num  
			if(num % 10 == 0)  
			{  
				// increase the trailing zero count by 1 remove the last trailing zero  
				cntTrailingZeros ++;
				num = num / 10;  
			}  
			else  
			{  
				return cntTrailingZeros; // trailing zeros is absent in the number num hence, return the count  
 
			}  
  
		}  
	}  
	
// main method  
	public static void main(String[] argvs)   
	{  
		// creating an object of the class TrailingZeros  
		TrailingZeros obj = new TrailingZeros();  
		  
		System.out.println("Enter the Number to find the factorial: ");
		Scanner sc= new Scanner(System.in);
		int num= sc.nextInt();
		long ans = obj.findFactorial(num);  
		  
		int cntTrailingZeros = obj.findCountTrailingZeros(ans);  
		  
		System.out.println("The factorial of the number " + num + " is: " + ans);  
		System.out.println("The number of trailing zeros in the number " + ans + " is: " + cntTrailingZeros);  
		System.out.println();  
	}
}