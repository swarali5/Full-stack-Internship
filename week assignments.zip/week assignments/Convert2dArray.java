package com.DailyAssignmet2.java;

import java.util.Arrays;
import java.util.Scanner;


public class Convert2dArray {

	public static int[][] convertarray(int[] array,int r,int c)
	{
		int counter=0;
		 if(r*c !=array.length) 
		 {
			 System.out.println("array Length mismatched ");
			 return new int[0][0];
		 }
		 
		int [][]res= new int[r][c];//initializing the result array
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				res[i][j]=array[counter];//loot for adding elemnts in 2d array
						counter++;//increment the counter ny 1
				
				
			}
		}return res;//return the res array
	}
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("ENter the length of an array :"); //accepting the length
		int len =sc.nextInt();
		System.out.println("Enter elements of an array : ");//accepting the array
		int array[]=new int[len];
		for(int i=0;i<len;i++)//loop to take the input from user
		{
			array[i]=sc.nextInt();
		}
		System.out.println("Enter the row and colomn for 2D array :"); 
		System.out.println("Row :");//taking no of rows from user
		int m= sc.nextInt();
		System.out.println("colomn :");//taking no of columns from user
		int n= sc.nextInt();
		int[][]ans=new int[m][n];
		ans=convertarray(array,m,n);//function call
		for(int i=0;i<ans.length;i++)//printing  the 2d array
		{
			System.out.println(Arrays.toString(ans[i]));
		}

	}	
	}

