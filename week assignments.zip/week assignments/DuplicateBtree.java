package com.DailyAssignmet2.java;
import java.util.HashMap;

public class DuplicateBtree {
 
    /* A binary tree node has data, pointer to
    left child and a pointer to right child */
    static HashMap<String, Integer> m;
    static class Node { //creating the node
        int data;
        Node left;
        Node right;
        Node(int data){ //initializing the root data and value
            this.data = data;
            left = null;
            right = null;
        }
    }
    static String inorder(Node node)
    {
        if (node == null)
            return "";
      
        String str = "(";
        str += inorder(node.left);
        str += Integer.toString(node.data);
        str += inorder(node.right);
        str += ")";
      

              
        if (m.get(str) != null && m.get(str)==1 ) //comparing the nodes
            System.out.print( node.data + " ");
      
        if (m.containsKey(str))
            m.put(str, m.get(str) + 1);
        else
            m.put(str, 1);
         
        
        return str;
    }
      
   
    static void printAllDups(Node root)
    {
        m = new HashMap<>();         // we use HashMap instead of HashSet because we want to print multiple duplicates
        inorder(root);
    }
    // Driver code
    public static void main(String args[])
    {
    	//initialisig the tree structure
        Node root = null;//adding root node
        root = new Node(1);//adding nodes to tree
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.right.left = new Node(2);
        root.right.left.left = new Node(4);
        root.right.right = new Node(4);
        printAllDups(root); //function call
    }
}