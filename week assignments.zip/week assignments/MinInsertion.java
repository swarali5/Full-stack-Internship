package com.DailyAssignmet2.java;

import java.util.Scanner;

public class MinInsertion {

	 public static int minInsertions(String s)
	 {
	        int Left = 0, Right = 0;

	        for(char c : s.toCharArray())//run the loop till string lenght
	        {
	            if(c == '(')//condtion check for '('
	            {
	                Right+=2; // increase right counter by 2
	                if(Right % 2 == 1){
	                    Right--;
	                    Left++;
	                }
	            }
	            if(c == ')'){
	                Right--;
	                if(Right == -1){
	                    Left+=1;
	                    Right = 1;
	                }

	            }
	        }
	        return Left + Right;
	    }
	 public static void main(String[] args) {
		//String s="())(()";
		 Scanner sc= new Scanner(System.in); //accepting the input from user
		 System.out.println("Enter the Parenthesis('(') : ");
		 String s=sc.next();
		 System.out.println("No. of Required closing parenthesis : "+minInsertions(s));//function call
	}
}
