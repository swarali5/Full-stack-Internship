package com.DailyAssignmet2.java;

import java.util.Scanner;

public class countVowels {

	public static long countvowels(String word) {
        long res = 0, prev = 0;
        for(int i=0; i<word.length(); i++) {
            char c = word.charAt(i);
            if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
                prev += i + 1;
            res += prev;
        }
        
        return res;
    }
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the String to check vowels in all substrings :");//take input from user
		String s= sc.next();
		
		long ans= countvowels(s);
		System.out.println(ans);
	}
}
