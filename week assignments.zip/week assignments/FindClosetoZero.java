package com.DailyAssignmet2.java;

import java.util.Scanner;

public class FindClosetoZero {
	public static int closestnumber(int[] arr)
	{
		if(arr==null || arr.length==0) //no numbers in an array return 0
		{
			return 0;
		}
		int close_num=arr[0];//assigning first number value in array to close_num 
		for(int i=1;i<arr.length;i++)
		{
			int temp=arr[i]; //second element saved in temp
			if(Math.abs(temp)<Math.abs(close_num))//if absolute value of second numver id smaller than first number
			{
				close_num= temp;//update first number with second and so on..
			}
			else if(Math.abs(temp) == Math.abs(close_num)&&(close_num<temp))
			{	//if  absulute second number is equal to first 
				close_num=temp; //update second number
			}
		}return close_num; //return the result
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	//taking the input from user
	System.out.println("Enter the length of an array : ");
	int len=sc.nextInt();
	System.out.println("Enter the numbers:");
	int[]arr=new int[len];
	for(int i=0; i<len;i++)//loop to take array of numbers
	{
		arr[i]=sc.nextInt();
	}
	
	 
	System.out.println("CLosest value to zero : "+closestnumber(arr));//functioj call
}
}
