package com.DailyAssignmet2.java;

import java.time.LocalDate;
import java.util.Scanner;

public class GetDayOftheYear {
    public static void main(String[] args)
    {
    	System.out.println("Enter the Date(yyyy-mm-dd) :");//take the ddate from the user
    	Scanner sc= new Scanner(System.in);
    	String date =sc.next();
        LocalDate dt = LocalDate.parse(date); // Parses the date
  
        // Prints the day number
        System.out.println(dt.getDayOfYear());
    }
}
