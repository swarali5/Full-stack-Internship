package com.DailyAssignmet2.java;

import java.util.Scanner;

public class PrefixWord {
	  public static int isPrefixOfWord(String sentence, String searchWord) {
	        String[] words = sentence.split(" ");
	        for (int i = 1; i <= words.length; ++i) {
	            if (words[i-1].startsWith(searchWord)) {
	                return i;
	            }
	        }
	        return -1;
	    }
	    public static void main(String[] args) {
	    	Scanner sc= new Scanner (System.in);
	    	//System.out.println("Enter the Sentence :");
	    	//String sentence =sc.next();
	         String sentence = "i love eating burger and pizza";
	         System.out.println(sentence);
	    	//System.out.println("Enter the Prefix word : ");
	    	String searchWord = "an";
	    	//String searchWord = sc.nextLine();
	    	System.out.println("Prefix word :"+searchWord);
	        System.out.print("Position of the word :"+isPrefixOfWord(sentence, searchWord));
	    }
	}

