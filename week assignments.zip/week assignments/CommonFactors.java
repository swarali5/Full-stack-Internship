package com.DailyAssignmet2.java;

import java.util.Scanner;

public class CommonFactors {
	public static int Commonfact(int n1,int n2)
	{ 
		int counter =0;
		int min= Math.min(n1, n2); //calculating minimum values from both numbers
		for(int i=1;i<=min;i++) 
		{
			if(n1%i ==0 && n2%i==0)//loop from 1 to min values and finding modulo .. 
			{
				counter++;//increasing the counter
			}
			
		}return counter;//return the counter value
	}
public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter both Numbers :");//taking the input from the user
	int n1=sc.nextInt();
	int n2=sc.nextInt();
	System.out.println("Number of common factors : "+Commonfact(n1,n2));//function call
}

}
