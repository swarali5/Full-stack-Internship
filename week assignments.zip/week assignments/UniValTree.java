package com.DailyAssignmet2.java;


public class UniValTree {
	static class node
	{
		int value;
		node left;
		node right;
		
		public node(int value)
		{
			this.value=value;
			left= null;
			right = null;
		}
	}
	node root;
	 public void PrintTree(node node) {
		 if(node!= null) {
			 PrintTree(node.left);
			 System.out.print(node.value+ " ");
			 PrintTree(node.right);
			 
		 }
		 
	 }
	 public static boolean IsUniVal(node root) {
		if(root ==null) {
			return true;
		}
		if(root.left != null && root.value != root.left.value)
		{
			return false;
			
		}
		if(root.right!=null && root.value != root.right.value)
		{
			return false;
		}
		 return IsUniVal(root.left) && IsUniVal(root.right);
	 }
	public static void main(String[] args) {
		UniValTree Btree = new UniValTree();
		Btree.root= new node(20);
		Btree.root.left =new node(20);
		Btree.root.right =new node(20);
		Btree.root.left.left = new node(20);
		Btree.root.left.right = new node(20);
		Btree.root.right.left =new node(20);
		
		
		System.out.println("Binary tree :");
		Btree.PrintTree(Btree.root);
		
		if(IsUniVal(Btree.root))
		{
			System.out.println("\nGiven Binary tree is UniValued Tree");
		}
		else
			System.out.println("\nGiven Binary tree is NOT a UniValued Tree");
	}

}
