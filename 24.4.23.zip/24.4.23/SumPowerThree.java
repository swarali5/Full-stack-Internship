package com.DailyAssignment.java;

import java.util.Scanner;

public class SumPowerThree
{
	static boolean PowerOfThree(int n)//function to check the sum of power of three
	{
		if(n==0) //if number if zero return false
			return false;
	
	while(n>0)//loop to check the number till zero 
	{
		if(n% 3 ==2) { //Digit cannot be 2 because then there are 2 of 3^i, therefore not distinct.
			return false;}
		n=n/3;
	}
	return true; 
	}
public static void main(String[] args) {
	Scanner sc=new Scanner (System.in); 
	System.out.println("Enter the number to check: ");//takig the number from user
	int n= sc.nextInt();
	
	
	if(PowerOfThree(n) == true) //condition check for true and false
	{
		System.out.println("True..");
	}else
		System.out.println("False");
}
}
