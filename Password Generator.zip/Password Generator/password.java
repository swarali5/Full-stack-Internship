package com.java;



import java.util.Scanner;
public class password {
    public static void main(String[] args) {
    	EnterPass();
    	
    }
    public static void EnterPass()
    {
        System.out.println("Enter password :");
        Scanner scanner = new Scanner(System.in);
        String s1 = scanner.nextLine();


          int n = Validation(s1);
          if(n == 1){
              System.out.println("Password Accepted..");
              if(s1.length()>=8 && s1.length()<=10)
              {
            	  System.out.println("Weak password");
              }
              else if(s1.length()>10 && s1.length()<=13)
              {
            	  System.out.println("Strong password");
              }
              else if( s1.length()>13 && s1.length()<=16)
              {
            	  System.out.println("Very Strong password");
              }
              
          }
          else {
              System.out.println("It is not a valid password \n");
              System.out.println("Password Should have\n"
              		+ "1.Atleast One Upper case letter\n"
              		+ "2.Atlest one lower case letter\n"
              		+ "3.Atlest one digit(0-9)\n"
              		+ "4.Atleast one character(!@#$%^&*)\n"
              		+ "5.Password should be between 8-16 characters");
              EnterPass();
          }
    }
    private static int Validation(String s1) {
        if(s1.matches(".*[0-9]{1,}.*") && s1.matches(".*[@#$%^&*]{1,}.*") && s1.length() >=8 && s1.length()<=16)
        {
            return  1;
        }
        else
        {
            return -1;
        }
    

    }
}

