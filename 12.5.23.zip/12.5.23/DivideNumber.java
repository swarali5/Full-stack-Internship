package com.DailyAssignment.java;

import java.util.Scanner;

public class DivideNumber {
	
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter a number: ");
	        int number = sc.nextInt();

	        int count = 0;
	        int digit;

	        // Iterate through each digit of the number
	        while (number != 0)
	        {
	            digit = number % 10;
	            // Check if the digit is a divisor of the number
	            if (digit != 0 && number % digit == 0) {
	                count++;
	            }
	            number /= 10;
	        }

	        System.out.println("Number of digits that divide the given number: " + count);
	    }
	 
}
