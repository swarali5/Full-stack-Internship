package com.DailyAssignment.java;

import java.util.Scanner;

public class PrimeSubtraction {
	 static boolean isPrime(int x)
	 {
	        if(x==0)
	        return true;
	        if(x==1)
	        return false;
	        for(int i=2;i<=Math.sqrt(x);i++){
	            if(x%i==0)
	            return false;
	        }
	        return true;
	    }
	    static int findPrime(int curr,int prev)
	    {
	        for(int i=curr-1;i>=0;i--){
	            if(curr-i>prev && isPrime(i))
	            return curr-i;
	        }
	        return -1;
	    }
	    public static boolean primeSubOperation(int[] nums)
	    {
	        int n=nums.length;
	        int prev=0;
	        for(int i=0;i<n;i++){
	            int temp=findPrime(nums[i],prev);
	            if(temp==-1)
	            return false;
	            prev=temp;
	        }
	        return true;
	    }
	    public static void main(String[] args) 
	    {
	    	System.out.println("Please enter the length of an array:");// taking the length of numbers
	        Scanner sc= new Scanner(System.in);//scanner class to accept numbers

	        int n = sc.nextInt();//storing value in variable n
	        
	        int[] nums = new int[n]; //array of n numbers
	        System.out.println("Enter Numbers :");
	        //loop to accept the numbers
	        for(int i = 0; i < n; i++) {
	            nums[i] = sc.nextInt();
	        }
	        System.out.println(primeSubOperation(nums));
		}
}
