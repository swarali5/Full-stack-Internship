package com.DailyAssignment.java;

/* A binary tree node has data, pointer to left child
  and a pointer to right child */
class Node {
   int data;
   Node left, right;

   Node(int item)//node constructor
   {
       data = item; //value
       left = right = null;//initialise at null for first root node
   }
}

public class WidthBtree {
   Node root;

   /* Function to get the maximum width of a binary tree*/
   int getMaxWidth(Node node) //function to get max width
   {
       int maxWidth = 0;
       int width;
       int h = height(node);//call for function height to check the height for binary tree
       int i;

       /* Get width of each level and compare
          the width with maximum width */
       for (i = 1; i <= h; i++) {
           width = getWidth(node, i);//call function width for each level of tree
           if (width > maxWidth)
               maxWidth = width; //set maxwidth 
       }

       return maxWidth;
   }

   /* Get width of a given level */
   int getWidth(Node node, int level)
   {
       if (node == null)
           return 0;

       if (level == 1)
           return 1;
       else if (level > 1)
           return getWidth(node.left, level - 1)
               + getWidth(node.right, level - 1);//recursion functin to calculate the width
       return 0;
   }



   /* calculate  the height of a tree i.e. the number of
    nodes along the longest path from the root node
    to the farthest leaf node.*/
   int height(Node node)
   {
       if (node == null)
           return 0;
       else {
           /* calculate the height of each subtree */
           int lHeight = height(node.left);
           int rHeight = height(node.right);

           
           return (lHeight > rHeight) ? (lHeight + 1)
                                      : (rHeight + 1); //return the largest height
       }
   }

   
   public static void main(String args[])
   {
       WidthBtree tree = new WidthBtree();//object of the binary tree class

      
       tree.root = new Node(1);//adding the roet node
       tree.root.left = new Node(2);//adding the left node at level 1
       tree.root.right = new Node(3);//adding the right node at level 1
       tree.root.left.left = new Node(4);
       tree.root.left.right = new Node(5);
       tree.root.right.right = new Node(8);
       tree.root.right.right.left = new Node(6);
       tree.root.right.right.right = new Node(7);
       /*
       Constructed binary tree is:
             1
           /  \
          2    3
        /  \    \
       4   5     8
                /  \
               6   7
        */

       // Function call to get maximum width
       System.out.println("Maximum width is "
                          + tree.getMaxWidth(tree.root));
   }
}