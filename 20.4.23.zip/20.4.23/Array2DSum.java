package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.List;

public class Array2DSum {


	/*function to Merge to two arrays*/
	    public int[][] mergeArrays(int[][] nums1, int[][] nums2) {
	       
	    	List<int[]> list = new ArrayList();//creating the object of new arraylist
	        int[][] result;
	        int i= 0, j = 0;
	        int n1 = nums1.length;//storing length of num1 array
	        int n2 = nums2.length;//storing length of num2 array

	       //loop will run for both arrays
			while(i < n1 && j < n2)
			{
	           if(nums1[i][0] == nums2[j][0])//if id of num1 ans num2 are same
	           {
	               nums1[i][1]+=nums2[j][1];//add values of num1 and num2
	               list.add(nums1[i]);//add num1 id to the list
	               i++;
	               j++;
	           }
	           else if(nums1[i][0] < nums2[j][0])//if num1 id is less than num2 add it to the list
	           {
	               list.add(nums1[i]);
	               i++;
	           }else{
	               list.add(nums2[j]);//if num2 id is less than num1 add it ot the list as it is
	               j++;
	           }
	        }

	        while(i < n1){
	            list.add(nums1[i]);
	            i++;
	        }  

	        while(j < n2){
	            list.add(nums2[j]);
	            j++;
	        }

	        result = new int[list.size()][2];//return the result of the list
	        
	        for(int n = 0; n < list.size(); n++)
	            result[n] = list.get(n);

	        return result;
	      }

    public static void main(String[] args) {
    	Array2DSum arr=new Array2DSum();//object of the class array
		int[][] num1= {{1,2},{3,4},{5,7}};//taking array with 2 dimensions
		int[][] num2= {{2,3},{3,5},{5,3}};
	
	/*	for(int i=0;i<num1.length;i++)
		{
			for(int j=0;j<num1[i].length;j++)
			{
				System.out.println(" array1 :"+num1[i][j]);
			}
		}*/
		int[][] ans = arr.mergeArrays(num1, num2);
		
		System.out.println("array lenghth: "+ans.length);
		System.out.println("Mergerd Array :");
		for(int i=0;i<ans.length;i++)
		{
			for(int j=0;j<ans[i].length;j++)
			{
				System.out.println(ans[i][j]);//callig the function to merge 2D aarrays
			}
		}
	}
}