package com.DailyAssignment.java;

import java.util.Arrays;
import java.util.Scanner;

public class MaxNumArray8_7 {
	 static int findMaximum(int[] arr, int n) {
	        Arrays.sort(arr); //sort array
	        return arr[n-1]; //return the last element
	    }
	 public static void main(String[] args) {
		 System.out.println("Enter the lenghth of an array  :");
			Scanner sc= new Scanner(System.in);
			int n= sc.nextInt();
			
			System.out.println("Enter the array elements :");
			int[] arr=new int[n];
			//take array elements from user
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.println("Max number: "+findMaximum(arr,n));
	}
}
