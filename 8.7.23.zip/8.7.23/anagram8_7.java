package com.DailyAssignment.java;

import java.util.Arrays;
import java.util.Scanner;

public class anagram8_7 {
	

	    final static int CHAR = 256;
	        
	    static int search(String pat, String txt) {
	        int count  =0;
	        int cntT [] = new int[CHAR];        //array for string txt
	        int cntP [] = new int[CHAR];        //array for string pat
	        for(int i=0; i<pat.length(); i++){
	            cntT[txt.charAt(i)]++;
	            cntP[pat.charAt(i)]++;
	        }
	        for( int i = pat.length(); i<txt.length(); i++){
	            if(Arrays.equals(cntT, cntP)){
	                count++;
	            }
	            cntT[txt.charAt(i)]++;          // adding a new element in the window
	            cntT[txt.charAt(i-pat.length())]--;   // removing the leftmost element from the window
	        }
	        if(Arrays.equals(cntT, cntP)){      // for checking the last window
	            count++;
	        }
	        return count;
	    }
	    public static void main(String[] args) {
			System.out.println("Enter first string (txt) : ");
			Scanner sc= new Scanner(System.in);
			String txt=sc.next();
			System.out.println("Enter second string (pat): ");
			String pat=sc.next();
			System.out.println("count :"+search(pat,txt));
			}
}
