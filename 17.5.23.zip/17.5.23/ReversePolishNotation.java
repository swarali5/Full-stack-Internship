package com.DailyAssignment.java;

import java.util.Scanner;
import java.util.Stack;

public class ReversePolishNotation {
	public static int stacky(String[] tokens)
    {
 
        // Initialize the stack and the variable
        Stack<String> stack = new Stack<String>();
        int x, y;
        String result = "";
        int get = 0;
        String choice;
        int value = 0;
        String p = "";
 
        // Iterating to the each character
        // in the array of the string
        for (int i = 0; i < tokens.length; i++) {
 
            // If the character is not the special character
            // ('+', '-' ,'*' , '/')
            // then push the character to the stack
            if (tokens[i] != "+" && tokens[i] != "-"
                && tokens[i] != "*" && tokens[i] != "/") {
                stack.push(tokens[i]);
                continue;
            }
            else {
                // else if the character is the special
                // character then use the switch method to
                // perform the action
                choice = tokens[i];
            }
 
            // Switch-Case
            switch (choice) {
            case "+":
 
                // Performing the "+" operation by popping
                // put the first two character
                // and then again store back to the stack
 
                x = Integer.parseInt(stack.pop());
                y = Integer.parseInt(stack.pop());
                value = x + y;
                result = p + value;
                stack.push(result);
                break;
 
            case "-":
 
                // Performing the "-" operation by popping
                // put the first two character
                // and then again store back to the stack
                x = Integer.parseInt(stack.pop());
                y = Integer.parseInt(stack.pop());
                value = y - x;
                result = p + value;
                stack.push(result);
                break;
 
            case "*":
 
                // Performing the "*" operation
                // by popping put the first two character
                // and then again store back to the stack
 
                x = Integer.parseInt(stack.pop());
                y = Integer.parseInt(stack.pop());
                value = x * y;
                result = p + value;
                stack.push(result);
                break;
 
            case "/":
 
                // Performing the "/" operation by popping
                // put the first two character
                // and then again store back to the stack
 
                x = Integer.parseInt(stack.pop());
                y = Integer.parseInt(stack.pop());
                value = y / x;
                result = p + value;
                stack.push(result);
                break;
 
            default:
                continue;
            }
        }
 
        // Method to convert the String to integer
        return Integer.parseInt(stack.pop());
    }

 

 
    public static void main(String[] args)
    {
        // String Input
    	System.out.println("Enter the lenghth of the string :");
    	Scanner sc= new Scanner (System.in);
    	int n=sc.nextInt();
    	String s[]=new String[n];
    	System.out.println("Enter the elements of string (numbers & operator): ");
    	for(int i=0;i<n;i++)
    	{
    		s[i]= sc.next();
    	}
      /* String[] s
            = { "2", "1", "+","3"
               , "*" };
*/
        
        System.out.println(stacky(s));
    }
}
