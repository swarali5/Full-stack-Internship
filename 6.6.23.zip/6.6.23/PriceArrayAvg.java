package com.DailyAssignment.java;

import java.util.Scanner;

public class PriceArrayAvg {
public static void main(String[] args) {
	System.out.println("Enter the length of array :"); //taking the input from user
	Scanner sc= new Scanner(System.in);
	int n= sc.nextInt();
	System.out.println("Enter the price array :");
	int[] arr= new int[n];
	int sum = 0; //declare sum
	for(int i=0;i<n;i++)//loop to take the array
	{
		arr[i]=sc.nextInt();
		sum+=arr[i]; //calculte sum of all the prices
	}
	 float avg= sum/n;
	String val= String.format("%.2f",avg); //converting avg to string 
	
	System.out.println("Sum of Prices : "+sum+"\nAverage of Prices : "+val);//printing the result

	
}

}

