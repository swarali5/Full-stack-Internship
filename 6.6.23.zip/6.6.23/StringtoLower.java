package com.DailyAssignment.java;

import java.util.Scanner;

public class StringtoLower {
public static void main(String[] args) {
	System.out.println(" please enter the string : ");//take user input
	Scanner sc=new Scanner(System.in);
	String s= sc.next();
	String s2= s.toLowerCase(); //convert string to lower case
	System.out.println("Lowercase :"+s2);//printing the result
}
}
