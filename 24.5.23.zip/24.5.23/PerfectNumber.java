package com.DailyAssignment.java;

import java.util.Scanner;

public class PerfectNumber
{
	public static boolean checkPerfectNumber(int num) {
        int num1 = 0;
        if(num % 2 != 0){
            return false;
        }else{
        
        for(int i  = 1 ; i<=num/2 ; i++){
            if(num % i == 0){
                num1 += i; 
            }
        }
        }

        return num1==num;
    }
	public static void main(String[] args) {
		System.out.println("Enter the number : ");
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		System.out.println("perfect Number : "+checkPerfectNumber(n));
	}

}
