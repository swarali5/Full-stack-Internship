package com.DailyAssignment.java;

import java.util.Scanner;

public class DeleteChar {
public static void main(String[] args) 
{
	System.out.println("Entert the String :");//taking the input from the user
	Scanner sc= new Scanner(System.in);
	String s= sc.next();
	String s2=""; //declare empty string to store the result
	for(int i=0;i<s.length();i++)//loop to traverse the string
	{
		if(i%2==0)// finding even values to store the result
		{
			s2+=s.charAt(i);// adding even  characters to new string
		}
	}
	System.out.println("New String : "+s2);//printing the result
}



}

