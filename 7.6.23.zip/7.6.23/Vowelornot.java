package com.DailyAssignment.java;

import java.util.Scanner;

public class Vowelornot {
public static void main(String[] args) {
	//taking the input from the user
	System.out.println("Enter the Character :");
	Scanner sc = new Scanner(System.in);
	char c = sc.next().charAt(0);//scanner class to accept the character variable
	char[] ch = {'a','e','i','o','u','A','E','I','O','U'}; //declare char array with vowels
    for(int i=0;i<ch.length;)
    {
        if(ch[i]==c) //if the given character maateches with vowel array print yes
        {
            System.out.println(" This character is a Vowel");
            
        }else if(ch[i]!=c) //else print no
            System.out.println("This chatacter is NOt a vowel");
        break; //break the loop

    }   

}
}
