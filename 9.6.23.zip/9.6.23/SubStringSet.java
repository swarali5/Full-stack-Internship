package com.DailyAssignment.java;

import java.util.HashSet;
import java.util.Scanner;

public class SubStringSet {
	 public static int unique_substring(String str)

	    {
//putting the string in hashset
	        HashSet<String> set = new HashSet<String>();

	        for (int i = 0; i < str.length(); i++) //loop for first letter
	        {

	            for (int j = i + 1; j <= str.length(); j++) //loop for next letter
	            {

	                set.add(str.substring(i, j)); //taking the substring in set

	            }

	        }
	        return set.size(); //return the size

}
	 public static void main(String[] args) 
	 {
		System.out.println("Enter the String : ");//taking the input from the user
		Scanner sc = new Scanner(System.in);
		String s= sc.next();
		System.out.println("unique Substring set :"+unique_substring(s)); //printing the size
	 }
}