package com.DailyAssignment.java;

import java.time.LocalDate;
import java.util.Scanner;

public class DayOftheWeek {
public static void main(String[] args)
{
	//taking the input from the user
	System.out.println("Enter the Date, month and the year :");
	System.out.println("Date : ");
	Scanner sc= new Scanner(System.in);//scanner class to accept the user input
	int date=sc.nextInt();
	System.out.println("Month :");
	int month=sc.nextInt();
	System.out.println("Year :");
	int year=sc.nextInt();
	
	System.out.println("Day of the week :"+findDay(date,month,year)); //functiion call
}
	static String findDay(int Day, int Month, int Year){
	      
	       LocalDate my_date = LocalDate.of(Year,Month,Day); //declare local date variable to stiore the result
	       return my_date.getDayOfWeek().name(); //return the day of the week
	   }
}

