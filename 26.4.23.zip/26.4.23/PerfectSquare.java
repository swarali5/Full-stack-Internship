package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.Scanner;

public class PerfectSquare {
	
    static int minCount(int n)
    
    {
 
        int[] minSquaresRequired = new int[n + 1];//declaring the array of to store minsquarerrot values
 
        minSquaresRequired[0] = 0;//initialize 1st value
 
        minSquaresRequired[1] = 1;//initialise 2nd value
 
        for (int i = 2; i <= n; ++i) //loop to store other squareroots and sum of it
 
        {
 
            minSquaresRequired[i] = Integer.MAX_VALUE;
 
            for (int j = 1; i - (j * j) >= 0; ++j)//loop to find the min value of i and i-sqaure of j
 
            {
 
                minSquaresRequired[i] = Math.min(minSquaresRequired[i], minSquaresRequired[i - (j * j)]);
            }
 
            minSquaresRequired[i] += 1;//add the values
        }
 
        int result = minSquaresRequired[n];
 
        return result;//return the result
    }
 
  
    public static void main(String[] args) {
    	//take the input from the user
    	System.out.println("Enter the target number to calculate perfect square : ");
        Scanner sc= new Scanner(System.in);
        int n=sc.nextInt();
        System.out.print(minCount(n));//function calls
    }
}
 


 
