package com.DailyAssignment.java;

import java.util.Scanner;

public class Max1sRow {
	static int rowWithMax1s(int arr[][], int n, int m) {
        for(int i=0;i<m;i++) //check the column for max 1s
        {
                    int j =0;
               while(j<n)
               {
                if(arr[j][i]==1)
                {
                    return j; //return row with max 1
                }
                   j++;
               } 
            
        }
      return -1; //else return -1
    }
	public static void main(String[] args) {
		//taking the input from user
		System.out.println("Enter no of rows (n):");
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("Enter no of colomns(m):");
		int m= sc.nextInt();
		System.out.println("enter matrix elemnets :");
		int[][] arr=new int[n][m];
		//accpet the 2 dimentional array
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		
		System.out.println(" row : "+rowWithMax1s(arr,n,m)); //printing the result
	}

}
