package com.DailyAssignment.java;

import java.util.Scanner;

public class MaxLengthArray {

	    public static int maximumValue(String[] strs) 
	    {
	        int ans = 0; 
	        for (String s : strs) //loop to take all the strings in the array
	            if (s.matches("[0-9]+")) //condition to check the number values
	            {
	            	ans = Math.max(ans, Integer.valueOf(s)); 
	            }
	            else 
	            	ans = Math.max(ans, s.length()); //else count the number of characters in the string 
	        return ans; //return the ans
	    }
	    public static void main(String[] args)
	    {
			System.out.println("Enter the length of an array : ");//taking the input from the user
			Scanner sc= new Scanner (System.in);
			int n= sc.nextInt();
			System.out.println("Enter the string/integer elements of array");//taking the elements from the user
			String[] arr= new String[n];
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.next();
			}
			System.out.println("length of the max string is : "+maximumValue(arr));//function call
				
	    }
	}
