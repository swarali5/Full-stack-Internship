package com.DailyAssignment.java;

import java.util.HashSet;
import java.util.Scanner;

public class PrimeFactor {
	 public static int distinctPrimeFactors(int[] nums) 
	    {
	        HashSet<Integer> set = new HashSet<Integer>();
	        for(int i:nums)
	        {
	            if(i%2==0)
	            {
	                set.add(2);
	                /* Until we get odd number the loop divides with prime number 2*/
	                while(i%2==0)
	                {
	                    i=i/2;
	                }
	            }
	            /* we have only have odd numbers upon above loop execution and now we divide with odd prime numbers*/
	            for(int j=3;j<=Math.sqrt(i);j+=2) 
	            {
	                while(i%j==0)
	                {
	                        set.add(j);           
	                        i/=j;
	                }
	            }
	            if(i>2) /* if we have the prime number greater than 2 then it is added to the set */
	                set.add(i);
	        }
	        return set.size();
	    }


	 	public static void main(String[] args) {
	 		System.out.println("Enter the length of an array : ");//taking the input from the user
			Scanner sc= new Scanner (System.in);
			int n= sc.nextInt();
			int arr[]=new int[n];
			System.out.println("Enter the elements of array");//taking the elements from the user
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
				
			System.out.println("Number of prime factor : "+distinctPrimeFactors(arr));//function call
			
			
		}

}
