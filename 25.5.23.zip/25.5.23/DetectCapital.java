package com.DailyAssignment.java;

import java.util.Scanner;

public class DetectCapital {
	public static boolean detectCapitalUse(String word) 
	{
        if(word.length() == 0 || word.length() == 1) //if word has no charatcters or only one char returt true
        	return true;
        
        if(Character.isUpperCase(word.charAt(0)))//if first letter is uppercase..
        {
            boolean isFirstCharacter = Character.isUpperCase(word.charAt(1));
            for(int i = 2; i < word.length(); i++) //traverse the word to check if all characters are upeercase after 2nd char
            {
                boolean currentChar = Character.isUpperCase(word.charAt(i));
                if(currentChar != isFirstCharacter) //if not uppercase.. return false
                	return false;
            }
        }
        else
        {
            for(int i = 1; i < word.length(); i++) 
            {
                if(Character.isUpperCase(word.charAt(i)))//if all the charachers are not lower case.. return false
                	return false;
            }
        }
        return true; //return true if all the characters are upper or lower or only first char is uppercase
	}
	public static void main(String[] args)
	{
		System.out.println("Enter the Word:"); //taking the input from the user
		Scanner sc= new Scanner(System.in);
		String word = sc.next();
		
		System.out.println("Output : "+detectCapitalUse(word));//function call
	}

}
