package com.DailyAssignment.java;

import java.util.Scanner;

interface In1 {
	int n=0;
	void display(int k);
}
class InterfaceJava implements In1{
	
	    static boolean isprime(int n){
	        if(n==1||n==0) //base case  for n0 and 1
	        {
	            return false;
	        }
	        for(int i=2;i<=Math.sqrt(n);i++) //check if the number is prime
	        {
	            if(n%i==0){
	                return false; 
	            }
	        }
	        return true;//ret7urn the result
	    }
	    public void display(int k)
	    {   
	        
	        int count=0;
	        for(int i=2;i<=k;i++) //till the index k recursive call ito is prime function
	        {
	            if(isprime(i)){
	                count++; //increament the counter each time
	            }
	        }
	        System.out.println("count : "+count);
	    }
	    public static void main(String[] args) 
	    {
	    	System.out.println("Enter K :"); //taking the input from user
	    	Scanner sc= new Scanner(System.in);
	    	int k=sc.nextInt();
	    	InterfaceJava ij= new InterfaceJava(); //creating the object of the class
			ij.display(k);
		}
		
}