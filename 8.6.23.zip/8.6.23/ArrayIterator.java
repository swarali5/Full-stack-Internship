package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class ArrayIterator {
	 static ArrayList<Integer> javaIterator(int n, int k, int[] arr) 
	 {
	       
	       ArrayList<Integer> arrList=new ArrayList<>(); //declare arraylist
	       for(int i=0;i<n;i++)
	       {
	           arrList.add(arr[i]); //adding the array elements to arraylist
	       }
	       Iterator<Integer> it=arrList.iterator(); 
	       while(it.hasNext()) //remove the elements below index k
	       {
	           int m=it.next();
	           if(m<k)
	           it.remove();
	       }
	       Collections.sort(arrList); //sorting the elements using collection
	       return arrList;
	   }
	 public static void main(String[] args) {
		 System.out.println("ENter the lenghth of an array:");//taking array lenght from user
	    	Scanner sc= new Scanner(System.in);//scanner class to accept the number
	    	int n= sc.nextInt();
	    	
	    	System.err.println("\nEnter the numbers of array: ");//taking the array 
	    	
	    	int[] arr= new int[n];
	    	for (int i=0;i<n;i++)
	    	{
	    		
	    		arr[i] = sc.nextInt();
	    	}
	    	System.err.println("Enter the index : "); //taking the index from user
	    	int k=sc.nextInt();
	    	System.out.println(javaIterator(n,k,arr)); //printing the o/p
	}
}
