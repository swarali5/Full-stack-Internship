package com.dailyAssignment3.java;

 class shape{
	 void print() {
	 System.out.println("this is shape class");
	 }
 }
 class circle extends shape
 {
	 void print() {
		 System.out.println("this is circle shape class");
		 }
 }
 class square extends shape{
	 void print() {
		 System.out.println("this is square shape class");
		 }
 }
public class Polymorphism {
	public static void main(String[] args) {
		shape obj= new shape();
		shape obj1 = new circle();
		shape obj2 = new square();
		 obj.print();
		 obj1.print();
		 obj2.print();
	}
}
