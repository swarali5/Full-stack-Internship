package com.dailyAssignment3.java;

import java.util.Scanner;

public class constructor {


	  private String name;
	  private int rating;

	  // constructor
	  constructor() {
	    System.out.println("Enter organisation name :");
	    Scanner sc= new Scanner(System.in);
	    name= sc.next();
	    System.out.println("Enter organisation rating :");
	    rating= sc.nextInt();
	    }

	  public static void main(String[] args) {

	    // constructor is invoked while
	    // creating an object of the Main class
		  constructor obj = new constructor();
	    System.out.println("The oraganisation name is " + obj.name + " has " + obj.rating +"* rating ");
	    
	  }
	}
