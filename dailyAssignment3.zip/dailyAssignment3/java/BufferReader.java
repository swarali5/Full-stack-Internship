package com.dailyAssignment3.java;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferReader {
	 public static void main(String[] args) throws FileNotFoundException
	    {
	  
	      
	        FileReader fileReader
	            = new FileReader(
	                "C:\\Users\\swarali shah\\Desktop\\username.docx");
	  
	        
	        try (BufferedReader buffReader = new BufferedReader(
			    fileReader)) {
				while (buffReader.ready()) {
				    
				    System.out.print(" "
				                       + (char)buffReader.read());
				}
			} catch (FileNotFoundException e) {
				throw e;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

}