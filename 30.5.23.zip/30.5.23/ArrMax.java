package com.DailyAssignment.java;

import java.util.Arrays;
import java.util.Scanner;

public class ArrMax {
	public static int arrayPairSum(int[] nums) {
    int max = 0;
    Arrays.sort(nums);//sorting the array elements in ascending order
    for(int i = 0;i<nums.length;i = i+2) //iterate the loop with 2 place increment
    {
      //  max = max + Math.min(nums[i],nums[i+1]);
    	max+=nums[i];//store addition in max
    }
    return max; //return the value
}
public static void main(String[] args) {
	System.out.println("ENter the lenghth of an array:");//taking array length from user
	Scanner sc= new Scanner(System.in);//scanner class to accept the number
	int n= sc.nextInt();
	
	System.err.println("\nEnter the numbers of array: ");//taking the array 
	
	int[] arr= new int[n];
	for (int i=0;i<n;i++)
	{
		arr[i] = sc.nextInt();
	}
System.out.println("Max value is : "+arrayPairSum(arr));
}

}
