package com.DailyAssignment.java;

import java.util.Scanner;

public class AdditiveNum {
	 public static boolean isAdditiveNumber(String num)
	 {

	        if(num == null || num.length() < 3)
	        {
	            return false;
	        }

	        return dfs(num, 0, 0, 0, 0);
	    }


	    private static boolean dfs(String num, int index, long prevSum, long prevNum, int count)
	    {
	        if(index == num.length()){
	            return count > 2;
	        }

	        long currentNum = 0; 

	        for(int i = index; i < num.length(); i++){
	            currentNum = currentNum * 10 + (num.charAt(i) - '0');

	            if(i > index && num.charAt(index) == '0'){
	                break;
	            }

	            if(count < 2 || currentNum == prevSum){
	                if(dfs(num, i+1, prevNum + currentNum, currentNum, count + 1)){
	                    return true;
	                }
	            }
	        }
	        return false;
	    }
	    public static void main(String[] args) 
	    {
			System.out.println("ENter the Number String :");//taking the input from user
			Scanner sc= new Scanner(System.in);
			String num= sc.next();
			System.out.println("Additive Number : "+isAdditiveNumber(num));//function call
		}
}
