package com.DailyAssignment.java;

import java.util.Scanner;

public class PowerOfThree 
{
	
	    public static boolean isPowerOfThree(int n)
	    {
	        if(n==1) return true; //if number is 1 return true
	        if(n%3 !=0 || n<=0) return false; //if reminder is not equal to zero return false
	        return isPowerOfThree(n/3);//divide the number by 3
	    }
	    public static void main(String[] args) {
			System.out.println("Enter the number :");//taking the input from the user
			Scanner sc= new Scanner(System.in);
			int n= sc.nextInt();
			System.out.println("IS the number power of three : "+isPowerOfThree(n));//function call
		}
}

