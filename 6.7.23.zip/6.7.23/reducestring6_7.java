package com.DailyAssignment.java;

import java.util.Scanner;
import java.util.Stack;

public class reducestring6_7 {
	
	    public static String reduced_String(int k, String s)
	    {
	        Stack<Character> st = new Stack<>();//declare stack variable
	        if(k==1){
	            return ""; //base case
	        }
	        for(int i =0;i<s.length();i++)
	        {
	            char ch = s.charAt(i);//add srting characters to stack
	            int count =1;
	            if(st.size()==0){
	                st.push(ch);
	            }
	            else if(st.peek()==ch) //remove the charachter from stack if found k times
	            {
	                while(st.size()>0 && st.peek()==ch &&count<=k){
	                    st.pop();
	                    count++;
	                }
	                if(count!=k){ //add character to stack if count of k is not matched
	                    for(int j=0;j<count;j++){
	                        st.push(ch);
	                    }
	                }
	            }
	            else{
	                st.push(ch);
	            }
	        }
	        StringBuilder ans= new StringBuilder();
	        while(st.size()>0){
	            ans.append(st.pop()); //append to string class
	        }
	        return ans.reverse().toString(); //convert stack to string
	    }
	    public static void main(String[] args) 
	    {
			System.out.println("Enter the Srting :"); //taking input from user
			Scanner sc= new Scanner(System.in);
			
			 String s=sc.next();
			System.out.println("Enter K: ");
			int k= sc.nextInt();
			System.out.println("Output :"+reduced_String(k,s));
		}

}
