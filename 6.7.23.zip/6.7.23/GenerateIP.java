package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class GenerateIP {
	 public static ArrayList<String> genIp(String str) {
	        
	        ArrayList<String> ans = new ArrayList<>(); //declaring arraylist variable
	        int n=str.length();//string length
	        if(n<4 || n>12){
	            ans.add("-1"); return ans;//base case
	        }
	        
	        HashSet<String> set = new HashSet<>();//declare hashset
	        for(int i=0; i<256; i++){
	            set.add(String.valueOf(i));//convert string to hashset
	        }
	        
	        for(int i=1; i<=3; i++){
	            StringBuilder ip1 = new StringBuilder(str);
	            ip1.insert(i,".");//insert dot every 3 digits
	            if(!set.contains(ip1.substring(0,i))) continue;
	            for(int j=i+2; j<=i+4 && j<ip1.length(); j++){
	                StringBuilder ip2 = new StringBuilder(ip1);
	                ip2.insert(j,".");
	                if(!set.contains(ip2.substring(i+1,j))) continue;
	                for(int k=j+2; k<=j+4 && k<ip2.length(); k++){
	                    StringBuilder ip3 = new StringBuilder(ip2);
	                    ip3.insert(k,".");
	                    if(set.contains(ip3.substring(j+1,k)) && set.contains(ip3.substring(k+1))){
	                        ans.add(ip3.toString());
	                    };
	                }
	            }
	        }
	        return ans;
	    }
	 public static void main(String[] args) 
	 {
		 System.err.println("Enter the String : ");
		 Scanner sc= new Scanner(System.in);
		 String s=sc.next();
		System.out.println("IP Address : "+genIp(s));

}
}