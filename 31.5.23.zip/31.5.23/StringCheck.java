package com.DailyAssignment.java;

import java.util.Scanner;

public class StringCheck {
	public static int minDistance(String s1, String s2) 
	{
		//taking the length of the strings
        int n = s1.length(); 
        int m = s2.length();
        //recursive function call if first string is less than second
        if (n < m)
        {
        	minDistance(s2, s1);
        }

        char[] WA1 = s1.toCharArray(); //converting string to character array
        char[] WA2 = s2.toCharArray();
        
        int[] dpLast = new int[m + 1];
        int[] dpCurr = new int[m + 1];
        
        for (char c1 : WA1)
        {
            for (int j = 0; j < m; j++)
            {
                if (c1 == WA2[j]) 
                {
                    dpCurr[j + 1] = dpLast[j] + 1;
                } else
                {
                    dpCurr[j + 1] = Math.max(dpCurr[j], dpLast[j + 1]);
                }
            }
            int[] tempArr = dpLast;
            dpLast = dpCurr;
            dpCurr = tempArr;
        }
        
        return n + m - 2 * dpLast[m];
    }
	public static void main(String[] args)
	{ 
		//taking the input from the user
		System.out.println("Enter the string 1 :");
		Scanner sc= new Scanner(System.in);
		String s1= sc.next();
		System.out.println("Enter the string 2:");
		String s2= sc.next();
		System.out.println("result :"+minDistance(s1,s2)); //function call
	}
}
