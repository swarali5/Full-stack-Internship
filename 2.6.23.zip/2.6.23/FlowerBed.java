package com.DailyAssignment.java;

import java.util.Scanner;

public class FlowerBed {
	 public static boolean canPlaceFlowers(int[] flowerbed, int n) {
	        int count = 0 ;
	        //loop to check if flower can be planted 
	        for(int i = 0 ; i < flowerbed.length; i++)
	        {
	            if(flowerbed[i]==0)
	            {
	                boolean emptyLeftplot = (i - 1 < 0 || flowerbed[i-1] == 0);//check the left adjacent position
	                 boolean emptyRightplot = (i + 1 >= flowerbed.length || flowerbed[i+1] == 0);//chrck the right adjacent posion
	                 if( emptyLeftplot && emptyRightplot )//if both empty increase the count
	                 {
	                     count++;
	                     flowerbed[i] = 1;
	                 }
	                
	            }
	        }
	        return count>= n; //return the result

	        
	    }
	 public static void main(String[] args) {
		 //taking the input from user
		 System.out.println("Enter the no of planted flowers :");
		 Scanner sc= new Scanner(System.in);
		 int n=sc.nextInt();
		System.out.println("Enter the planted array :");//planted flower array
		int[] arr= new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		
		System.out.println("Enter the position to plant flower :\n");//new flower position
		int pos =sc.nextInt();
		for(int i=0;i<n;i++)
		{
		System.out.print(arr[i]);
		}
		System.out.println("\nResult :"+canPlaceFlowers(arr,pos));//function call
	}
}
