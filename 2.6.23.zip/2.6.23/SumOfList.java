package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class SumOfList {
	public static String[] findRestaurant(String[] list1, String[] list2) 
	{
        Map<String,Integer> map=new HashMap<>(); //declare map
        List<String> list=new ArrayList<>();//declare list in arraylist 
        int sum=Integer.MAX_VALUE;
        for(int i=0;i<list1.length;i++)  //put first list elements in map
        	map.put(list1[i],i);
        for(int i=0;i<list2.length;i++) // loop to check the similar values in both list
        {
            Integer k=map.get(list2[i]);
            if(k!=null && k+i<sum ){
                list.clear();
                sum=k+i;
                list.add(list2[i]);
            }
             
            else if(k!=null && k+i<=sum){
                list.add(list2[i]); 
            }
        }
        //return the arraylist of similar first element
        return list.toArray(new String[list.size()]);
    }
	public static void main(String[] args) {
		//taking input from user
		String s1[] =new String[]{"apple","Peru","Mango"};
		String s2[] =new String[]{"Kiwi","apple","Peru","Mango",};
		
		
		String[] res=findRestaurant(s1,s2);
		//printing the result array
		for(int i=0;i<res.length;i++)
		{
		System.out.println(res[i]);
		}
		
	}
}
