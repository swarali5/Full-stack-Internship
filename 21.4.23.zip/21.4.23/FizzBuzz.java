package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class FizzBuzz {
public static void main(String[] args) 
{
	System.out.println("Enter the lenght of numbers to check for Fizbuzz : ");//taking the length of the numbers
	Scanner sc= new Scanner(System.in);
	int n= sc.nextInt();
	FizzBuzz fb = new FizzBuzz(n);
	fb.printFizzBuzz();

	
         /* for (int i=1; i<=n; i++)                                
     {
         //if number is divisible by 3&5 write Fizzbuzz in place of the number
         if (i%3==0 && i%5==0)                                                
             System.out.println("FizzBuzz");
         // number divisible by 5, print 'Buzz' in place of the number
         else if (i%5==0)    
             System.out.println("Buzz");

         // number divisible by 3, print 'Fizz'
         // in place of the number
         else if (i%3==0)    
             System.out.println("Fizz");
              
         else // print the numbers
             System.out.println(i);                        
     }*/
}     
		static List<String> fizzBuzzList = new ArrayList<>(); //creating the static list object
         public FizzBuzz( int end){
        	  
              FizzBuzz.CheckFizzBuzz( end);
          }

          private static List<String> CheckFizzBuzz(int end){ //list functin to check to conditions
              for (int i = 1 ; i <=end; i++){
                  if (((i % 3) == 0) && ((i % 5) == 0))  //if number is divisible by 3&5 write Fizzbuzz in place of the number
                  {  
                	  fizzBuzzList.add("FizzBuzz");
                  }
                  else if ((i % 3) == 0) {// number divisible by 3, add 'Fizz' in place of the number in list
                      fizzBuzzList.add("Fizz");
                  }
                  else if ((i % 5) == 0){ // number divisible by 5, add 'Buzz' in place of the number to list
                      fizzBuzzList.add("Buzz");
                  }
                  else{
                      fizzBuzzList.add(Integer.toString(i));// else add number to list
                  }
              }
              return fizzBuzzList; //return thr list
          }

          //function to print the list 
          public void printFizzBuzz(){
             
                  System.out.println(fizzBuzzList);
          
          }
}

