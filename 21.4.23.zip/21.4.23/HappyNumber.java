package com.worksheet.java;

import java.util.Scanner;

public class HappyNumber {
    public static int isNumHappy(int num) {
        int rem = 0, sum = 0;
        // calculate the sum of squares of each digit
        while (num > 0) {
            rem = num % 10; //calculating the reminder and getting the value of the digits separately
            sum = sum + (rem * rem); //adding squares of digits and storing in sum
            num = num / 10;//taking the next digit
        }
        return sum;
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number greater than 0:");//taking the number from user
        int val = sc.nextInt();
        
        while (val != 1 && val != 4) { //checking the condition and calliung the function to get the sum
            val = isNumHappy(val);
        }
        if (val == 1) { //if value is 1 then its a happy number
            System.out.println("The number entered is a Happy Number");
        } else {
            System.out.println(" The number entered is not a Happy Number");
        }
    }
}