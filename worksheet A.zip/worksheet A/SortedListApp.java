package com.list.java;


 class Node {

    public int iData;
    public Node next;

    public Node(int id) {
        iData = id;
    }

    public void display() {
        System.out.println(iData + " ");
    }

}
 class SortedList {

	    private Node first;

	    public SortedList() {
	        first = null;
	    }

	    public boolean isEmpty() {
	        return first == null;
	    }

	    public void insert(int j) {
	        Node newNode = new Node(j);
	        Node previous = null;
	        Node current = first;

	        while (current != null && j > current.iData) {
	            previous = current;
	            current = current.next;
	        }

	        if (previous == null)
	            first = newNode;

	        else

	            newNode.next = current;
	        previous.next = newNode;

	    }

	    public Node remove() {
	        Node temp = first;
	        first = first.next;
	        return temp;
	    }

	    public void displayList() {
	        System.out.println("First to -----> Last");
	        Node current = first;

	        while (current != null) {
	            current.display();
	            current = current.next;
	        }
	    }

	}


public class SortedListApp {
	public static void main(String[] args) {
		
	
	SortedList list = new SortedList();
	

    list.insert(20);
    list.insert(40);

    list.displayList();

    list.insert(10);
    list.insert(30);
    list.insert(50);

    list.displayList();

    list.remove();

    list.displayList();

}
}