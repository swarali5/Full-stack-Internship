 package com.list.java;
import java.util.*;  

 public class leftBinaryTree   
{  

	int val;  
	
	leftBinaryTree left, right;  
	 
public leftBinaryTree(int j)  
	{  
		val = j;  
		right = null;  
		left = null;  
		}  
}
 
 class LeftViewExample1   
{  
		leftBinaryTree r = null;  
		
		public void displayLeftView()  
		{  
			if (r == null)  
			{  
				return;  
			}  
		Queue<leftBinaryTree> que = new LinkedList<>();  
		que.add(r);  
		while (!que.isEmpty())   
		{  
		
			int siz = que.size();  
		 
			for (int j = 1; j <= siz; j++)   
			{  
				leftBinaryTree tmp = que.poll();  
		  
				if (j == 1)  
				{  
					System.out.print(tmp.val + " ");  
				}  
		
				if (tmp.left != null)  
				{  
					que.add(tmp.left);  
				}  
		  
				if (tmp.right != null)  
				{  
					que.add(tmp.right);  
				}  
			}  
		}  
}  
//main method  
public static void main(String argvs[])  
{  

	LeftViewExample1 lv = new LeftViewExample1();  
	
	lv.r = new leftBinaryTree(20);  
	
	lv.r.left = new leftBinaryTree(22);  
	lv.r.right = new leftBinaryTree(8);  
	lv.r.left.left = new leftBinaryTree(25);  
	lv.r.left.right = new leftBinaryTree(3);  
	lv.r.right.right = new leftBinaryTree(5);  
	lv.r.left.right.right = new leftBinaryTree(10);  
	lv.r.left.right.left = new leftBinaryTree(14);  
	lv.r.left.right.left.right = new leftBinaryTree(7);  
	System.out.println("The following are the nodes present in the left view of the Binary Tree: ");  
	
	lv.displayLeftView();  
}  
}