package com.list.java;





import java.util.Scanner;
public class BinaryTree {

	public static void main(String arg[])	
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number of nodes in a binary tree :");
	int nodes=sc.nextInt();
	int c=0;	    	
	int n=nodes;
	while(nodes!=1)
	{
	nodes=nodes/2;	
	c++;	
	}   
	    System.out.println("height of a binary tree :"+c);
	   System.out.println("height of a binary tree in worst case :"+(n-1));
	 
	}
}