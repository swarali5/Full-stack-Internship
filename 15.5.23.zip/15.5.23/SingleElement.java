package com.DailyAssignment.java;

import java.util.Arrays;
import java.util.Scanner;

public class SingleElement {
	 public static int singleNumber(int[] nums) {
	        Arrays.sort(nums);
	        if(nums.length==1)//if there is only one element in the array return that element
	        {
	            return nums[0];
	        }
	        for(int i=0;i<nums.length-1;i+=2)//compare 1st number with all others and incremnet by 2
	        {
	            if(nums[i]!=nums[i+1]){
	                return nums[i];
	            }
	        }
	       return nums[nums.length-1];//return the number with is not matched
	    }
	 public static void main(String[] args) {
		 System.out.println("Please enter the length of an array:");// taking the length of numbers
	        Scanner sc= new Scanner(System.in);//scanner class to accept numbers

	        int n = sc.nextInt();//storing value in variable n
	        
	        int[] nums = new int[n]; //array of n numbers
	        System.out.println("Enter Numbers :");
	        //loop to accept the numbers
	        for(int i = 0; i < n; i++) {
	            nums[i] = sc.nextInt();
	        }
	        System.out.println("Single Element in an array is : "+singleNumber(nums));
	}
}
