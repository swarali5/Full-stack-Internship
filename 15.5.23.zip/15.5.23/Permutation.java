package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Permutation {
	 public static String getPermutation(int n, int k) {
	        int fact = 1;
	        List<Integer> al = new ArrayList<>();
	        for(int i = 1;i < n; i++){
	            fact *= i;
	            al.add(i);
	        }
	        al.add(n);
	        String ans = "";
	        k--;
	        while(true){
	            ans += al.get(k / fact); //finding the index where the value should start
	            al.remove(k / fact); // after finding that value we need to delete that from list
	            if(al.size() == 0)
	                break; // if list is empty then done;
	            k %= fact;  //again decrease k value and apply for other values.
	            fact /= al.size();
	        }
	        return ans;
	    } 
	 public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number for factorial : ");
		int n=sc.nextInt();
		System.out.println("Enter the Permutation Index: ");
		int k= sc.nextInt();
		System.out.println("permutation is: "+getPermutation(n,k));
	}
}



