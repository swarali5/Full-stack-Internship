package com.DailyAssignment.java;

import java.util.Scanner;

public class nextHappyNumber
{
	
	static int nextHappy(int N)
	{
        for(int i=N+1;i<Integer.MAX_VALUE;i++)//loop to check the next happy number
        {
            if(happy(i)) //function call
            	return i; //if its a happy number return the result
        }
        return 0;
    }
    
    static boolean happy(int n) 
    {
        if(n==1)
        	return true;
        if(valid(n)==1 || valid(n)==7) //function call to check if its happy 
        {
            return true;
        }
        return false;
    }
    //functi0on to check the number is happy
    static int valid(int n)
    {
        int sum=0;
        while(n>0) //loop to check the sum of digits
        {
            int rem = n%10; //reminder 
            sum+=(rem*rem); //sum
            n=n/10; 
        }
        if(sum<10)//if the number is less than 10 return the number
        {
            return sum;
        }
        return valid(sum); //recursive call to add didgits
        
    }
    public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("ENter the Number :");//taking the input from user
		int n= sc.nextInt();
		System.out.println("NExt happy number is : "+nextHappy(n));//function call
	}

}
