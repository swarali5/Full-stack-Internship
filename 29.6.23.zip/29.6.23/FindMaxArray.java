package com.DailyAssignment.java;

import java.util.Scanner;

public class FindMaxArray {
	static int findMaximum(int arr[], int n) 
	{ 
	     int low=0,high=n-1; //initializing first and last number as low and high
	     while(low<=high)
	     {
	         int mid=low + (high-low)/2; //finding the middle number
	         
	         if(mid+1 <n && mid-1>=0)
	         {//check for not go outside of the array 
	             if(arr[mid]>arr[mid+1] && arr[mid]>arr[mid-1]){
	                 return arr[mid]; //return mid
	                // break;
	             }
	             else if(arr[mid]>arr[mid+1] && arr[mid]<arr[mid-1])
	             {//max left 
	                 high=mid-1;
	             }
	             else{
	                 low=mid+1;
	             }
	         }
	         
	     }
	     return arr[n-1]; //return max number
	        
	     
	   
	}
	public static void main(String[] args) 
	{// taking the input from user
		System.out.println("Enter the lenghth of an array :");
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		System.out.println("Enter the array elements :");
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Maximum Number is :"+findMaximum(arr,n)); //function call
	}
}
