package com.DailyAssignment.java;


  
public class treePath
{
	static class Node // creating a node
	{
	    int data;
	    Node left, right;
	  
	    Node(int item)// node constructor 
	    {
	        data = item;
	        left = right = null;
	    }
	}
    Node root;
      
    
    void printPaths(Node node)       //recursive function to  print all of its root-to-leaf paths */
    {
        int path[] = new int[1000];
        printPathsRecur(node, path, 0);
    }
  
    /* Recursive function -- given a node, and an array
       containing the path from the root node up to but not
       including this node, print out all the root-leaf paths.*/
    void printPathsRecur(Node node, int path[], int pathLen)
    {
        if (node == null)
            return;
  
        /* append this node to the path array */
        path[pathLen] = node.data;
        pathLen++;
  
        /* it's a leaf, so print the path that lead to here  */
        if (node.left == null && node.right == null)
            printArray(path, pathLen);
        else
        {
            /* otherwise try both subtrees */
            printPathsRecur(node.left, path, pathLen);
            printPathsRecur(node.right, path, pathLen);
        }
    }
  
    /*  function that prints out an array on a line. */
    void printArray(int ints[], int len)
    {
        int i;
        for (i = 0; i < len; i++)
        {
            System.out.print(ints[i] + " ");
        }
        System.out.println("");
    }
  
    public static void main(String args[])
    {
        treePath tree = new treePath();
        tree.root = new Node(1);
        tree.root.left = new Node(5);
        tree.root.right = new Node(2);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(8);
        tree.root.right.left = new Node(9);
        tree.root.right.left.right=new Node(3);
         
      
        tree.printPaths(tree.root); //function call
    }
}
