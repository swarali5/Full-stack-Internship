package com.DailyAssignment.java;

import java.util.HashMap;

public class ReplaceArray {

    public static int[] arrayChange(int[] nums, int[][] opt) {
        HashMap<Integer,Integer> map=new HashMap<>();
        
        for(int i=0;i<nums.length;i++){
            map.put(nums[i],i);
        }
        
        for(int i=0;i<opt.length;i++){
            int oldNum=opt[i][0];
            int newNum=opt[i][1];
            
            if(map.containsKey(oldNum)){
                int index=map.get(oldNum);
                nums[index]=newNum;
                
                map.put(newNum,index);
            }
        }
        return nums;
    }
    public static void main(String[] args) {
		int[] num= {1,2,3,4,5,7};
		int opt[][]= {{1,3},{2,4},{7,2}};
		int[] ans=new int[num.length];
		ans=arrayChange(num,opt);
		
		for(int i=0;i<ans.length;i++)		{
			
			System.out.print(ans[i]+" ");
		}

		
	}
}
