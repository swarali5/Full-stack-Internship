package com.DailyAssignment.java;

import java.util.Scanner;

public class SubarrayLCM {
	
	    public static int subarrayLCM(int[] nums, int k) {
	        int ans = 0;
	        for (int i = 0; i < nums.length; i++){
	            int c = nums[i];
	            for (int j = i; j < nums.length; j++){
	                c = lcm(c,nums[j]);
	                if (c == k){
	                    ans++;
	                }
	                if (c > k){
	                    break;
	                }
	            }
	        }
	        return ans;
	    }

	    public static int gcd(int a, int b){//loop for gcd
	        if (a == 0){
	            return b;
	        }
	        return gcd(b%a,a);
	    }

	    public static int lcm(int a,int b){//function for lcm
	        return (a*b)/(gcd(a,b));
	    }
	    public static void main(String[] args) {
	    	Scanner sc= new Scanner(System.in);
			System.out.println("ENter the length of an array :"); //accepting the length
			int len =sc.nextInt();
			System.out.println("Enter elements of an array : ");//accepting the array
			int array[]=new int[len];
			for(int i=0;i<len;i++)//loop to take the input from user
			{
				array[i]=sc.nextInt();
			}
			System.out.println("Enter the LCM number : ");
			int n= sc.nextInt();
			int ans=subarrayLCM(array,n);
			System.out.println("number Of Subarray of LCM :"+ans);
		}
	}