package com.DailyAssignment.java;
import java.io.*;
import java.util.Scanner;


public class NumOccurance {

/* if x is present in arr[] then returns the index of
    FIRST occurrence of x in arr[0..n-1], otherwise
    returns -1 */
    public static int first(int arr[], int low, int high,
                            int x, int n)
    {
        if (high >= low) {
            int mid = low + (high - low) / 2;// finding the mid of the array
            if ((mid == 0 || x > arr[mid - 1])//if target number is greater than mid-1 or mid is equal to zero and array of mid position is equal to target number, return mid 
                && arr[mid] == x)
                return mid;
            else if (x > arr[mid]) // if target is greater than array[mid] call recursion function first 
                return first(arr, (mid + 1), high, x, n);//first position will be mid+1 since target is greater than mid value.
            else
                return first(arr, low, (mid - 1), x, n);//else lst position will be mid-1 since target is less than mid value.
        }
        return -1;//if target is not found return -1
    }
 
    /* if x is present in arr[] then returns the index of
    LAST occurrence of x in arr[0..n-1], otherwise
    returns -1 */
    public static int last(int arr[], int low, int high,
                           int x, int n)
    {
        if (high >= low) {
            int mid = low + (high - low) / 2;// finding the mid of the array
            if ((mid == n - 1 || x < arr[mid + 1])//if mid is eqaul to last nmnber or target is less than mid+1 and mid value is target return midvalue
                && arr[mid] == x)
                return mid;
            else if (x < arr[mid])// if target is less that mid value 
                return last(arr, low, (mid - 1), x, n);//call recursion function last with high value Mid-1
            else
                return last(arr, (mid + 1), high, x, n);// call recursion function last with low value Mid+1
        }
        return -1;//if target is not found return -1
    }
 
    public static void main(String[] args)
    {
    	System.out.println("ENter the lenghth of an array:");//taking array lenght from user
    	Scanner sc= new Scanner(System.in);//scanner class to accept the number
    	int n= sc.nextInt();
    	
    	System.err.println("\nEnter the numbers of array: ");//taking the array 
    	
    	int[] arr= new int[n];
    	for (int i=0;i<n;i++)
    	{
    		arr[i] = sc.nextInt();
    	}
        System.out.println("\nENter the Target NUmber :");//taking the target number to find the occurrence
        int x = sc.nextInt();
        System.out.println("First Occurrence = "
                           + first(arr, 0, n - 1, x, n));//call for function first occurrence with arguments array, Fisrt  position,last position,Arraylenght,Target number
        System.out.println("Last Occurrence = "
                           + last(arr, 0, n - 1, x, n));////call for function last occurrence with arguments array, Fisrt  position,last position,Arraylenght,Target number
    }
}