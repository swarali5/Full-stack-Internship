package com.DailyAssignment.java;
 
 
public class TreePruning {
	static class TreeNode
	{ //creating the tree node
	    public static TreeNode root;
		int val;
	    TreeNode left;
	    TreeNode right;
	    TreeNode() {}
	    TreeNode(int val)
	    { 
	  	  this.val = val;
	    }
	    TreeNode(int val, TreeNode left, TreeNode right) 
	    {
	        this.val = val;
	        this.left = left;
	        this.right = right;
	    }
	}
	public static TreeNode pruneTree(TreeNode root)
	{ //add null if there is no node 
        if(root==null)
        {
        	return null;
        } //recursive function call
        root.left= pruneTree(root.left);
        root.right=pruneTree(root.right);
        
        if(root.val==0&&root.left==null&&root.right==null)
        {return null;}
         
        return root;
    }
	public static void main(String[] args) 
	{//making the tree structure
    	TreeNode root = new TreeNode(1);
       // root.left = new TreeNode(2);
      //  root.left.left = new TreeNode(4);
      //  root.left.right = new TreeNode(5);
        root.right = new TreeNode(0);
        root.right.right = new TreeNode(1);
        System.out.println(pruneTree(TreeNode.root));
	}
}
