package com.DailyAssignment.java;

import java.util.LinkedList;
import java.util.Queue;


	public class treeValDepth 
	{
        int val;
        treeValDepth left;
        treeValDepth right;
 
        // Constructor
        treeValDepth(int v)
        {
            val = v;
            left = right = null;
        }
    
	
    // Function to add one row to a
    // binary tree
    public static treeValDepth addOneRow(treeValDepth root, int val,
                                     int depth)
    {
        Queue<treeValDepth> q = new LinkedList<>();
        if (depth == 1) {
        	treeValDepth rt = new treeValDepth(val);
            rt.left = root;
            return rt;
        }
        int c = 1;
        q.offer(root);
        while (!q.isEmpty() && c < depth) {
            int a = q.size();
            c++;
            for (int i = 0; i < a; i++) {
                treeValDepth k = q.poll();
                if (c == depth) {
                    if (k.left != null) {
                    	treeValDepth tm = new treeValDepth(val);
                    	treeValDepth t = k.left;
                        k.left = tm;
                        tm.left = t;
                    }
                    else {
                    	treeValDepth tm = new treeValDepth(val);
                        k.left = tm;
                    }
 
                    if (k.right != null) {
                        treeValDepth tm = new treeValDepth(val);
                        treeValDepth t = k.right;
                        k.right = tm;
                        tm.right = t;
                    }
                    else {
                    	treeValDepth tm = new treeValDepth(val);
                        k.right = tm;
                    }
                }
                else {
                    if (k.left != null)
                        q.offer(k.left);
                    if (k.right != null)
                        q.offer(k.right);
                }
            }
        }
        return root;
    }
 
    // Function to print the tree in
    // the level order traversal
    public static void levelOrder(treeValDepth treeValDepth)
    {
        Queue<treeValDepth> Q = new LinkedList<>();
 
        if (treeValDepth == null) {
            System.out.println("Null");
            return;
        }
 
        // Add root node to Q
        Q.offer(treeValDepth);
 
        while (Q.size() > 0) {
            // Stores the total nodes
            // at current level
            int len = Q.size();
 
            // Iterate while len
            // is greater than 0
            while (len > 0) {
                // Stores the front Node
            	treeValDepth temp = Q.poll();
 
                // Print the value of
                // the current node
                System.out.print(temp.val + " ");
 
                // If reference to left
                // subtree is not NULL
                if (temp.left != null)
 
                    // Add root of left
                    // subtree to Q
                    Q.offer(temp.left);
 
                // If reference to right
                // subtree is not NULL
                if (temp.right != null)
 
                    // Add root of right
                    // subtree to Q
                    Q.offer(temp.right);
 
                // Decrement len by 1
                len--;
            }
 
            System.out.println();
        }
    }
    
   
    public static void main(String[] args)
    {
        // Given Tree
    	treeValDepth root = new treeValDepth(1);
        root.left = new treeValDepth(2);
        root.left.left = new treeValDepth(4);
        root.left.right = new treeValDepth(5);
        root.right = new treeValDepth(3);
        root.right.right = new treeValDepth(6);
 
        int L = 2;
        int K = 1;
 
        levelOrder(addOneRow(root, K, L));//function call
    }
}
