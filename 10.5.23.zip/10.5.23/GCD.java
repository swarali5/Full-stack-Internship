package com.DailyAssignment.java;

import java.util.Scanner;

public class GCD {
	public static int minOperations(int[] nums) 
	{
        int noOfOnes = 0;
        for (int num : nums) {
            if (num == 1)
            	
            	noOfOnes++;
        }
        if (noOfOnes > 0) 
        	return nums.length - noOfOnes;
        
        int ans = Integer.MAX_VALUE;
        for (int i = 0; i < nums.length; i++) 
        {
            int gcd = nums[i]; // Take initial GCD of the [i, j] range
            for (int j = i + 1; j < nums.length; j++) 
            {
                gcd = findGCD(gcd, nums[j]);  // For every new j, take gcd(nums[j], previousGCD) 
                if (gcd == 1) 
                	ans = Math.min(ans, j - i + nums.length - 1);
            }
        }
        return ans == Integer.MAX_VALUE ? -1 : ans;
    }

    private static int findGCD(int a, int b) {
        if (a == 0) 
        	return b;
        return findGCD(b % a, a);
    }
    public static void main(String[] args) {
    	System.out.println("Enter the length of an array : ");//taking the input from the user
		Scanner sc= new Scanner (System.in);
		int n= sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the elements of array");//taking the elements from the user
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
			
		System.out.println("Minimum no of operations are : "+minOperations(arr));//function call
		
	}
}
