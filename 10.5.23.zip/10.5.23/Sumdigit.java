package com.DailyAssignment.java;

import java.util.Scanner;

public class Sumdigit {
	 public static boolean sumOfNumberAndReverse(int num)
	 {
         for(int i = 0; i <= num; ++ i)//loop will run till the number
         {
            int n = i;
            int r = 0;
            while(n != 0) //calculate the reminder and reverse the number
            {
                r = r * 10 + n % 10;
                n = n / 10;
            }
            if(r + i == num) //if the reminder ans sum is equal to original number return true
            	return true;
        }
        return false;
    }
	 public static void main(String[] args) {
		System.out.println("Enter the Number :");//taking the input from the user
		Scanner sc= new Scanner(System.in);
		int num= sc.nextInt();
		System.out.println(sumOfNumberAndReverse(num));
	}
}
