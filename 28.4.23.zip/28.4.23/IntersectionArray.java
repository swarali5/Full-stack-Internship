package com.DailyAssignment.java;

import java.util.Arrays;

public class IntersectionArray {

	   public static void main(String args[]) {
		      int arr1[] = {2, 4,3, 6, 8, 9};
		      int arr2[] = {1, 3, 4, 5, 6, 8, 2,9};
		    //Sorting the arrays in ascending order
		      Arrays.sort(arr1);
		      Arrays.sort(arr2);
		      //taking the length of an array 
		      int m = arr1.length;
		      int n = arr2.length;
		      
		      int i = 0, j = 0;
		      //Printing both the arrays
		      System.out.print("Array 1: ");
		      for(int k = 0; k < m; k++) {
		         System.out.print(arr1[k] + " "); 
		      }
	
		      System.out.print("\nArray 2: ");
		      for(int k = 0; k < n; k++) {
		         System.out.print(arr2[k] + " ");
		      }
		    
		      System.out.print("\nIntersection of two arrays is: ");
		      while (i < m && j < n) //loop will run till the length of the arrays
		      {
		         if (arr1[i] < arr2[j]) //condition to compare the elements of both the arrays
		            i++;
		         else if (arr2[j] < arr1[i])
		            j++;
		         else {
		            System.out.print(arr2[j++]+" ");
		            i++; 
		         }
		      }
		   }
		}
