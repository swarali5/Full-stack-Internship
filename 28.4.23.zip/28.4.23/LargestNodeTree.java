package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class LargestNodeTree {

	//Initializing the node with value
	public static class TreeNode {      
	    int val;
	    TreeNode left;
	    TreeNode right;
	     
	    TreeNode(int x) {
	        val = x;
	    }
	}
	//list function to calculate the largest node in each level
	public List<Integer> largestValues(TreeNode root) {
	     
	    List<Integer> result = new ArrayList<>();        
	    if(root == null)
	    	return result;
	     
	    Queue<TreeNode> queue = new LinkedList<>();
	    queue.add(root);
	     
	    int size, value;
	    while(queue.size() > 0)//loop to calculate the highest value
	    {            
	        value = Integer.MIN_VALUE;
	        size = queue.size();            
	        for( int i=0; i<size; i++)// loop to add highest value to a result
	        {                
	            root = queue.poll();                
	            if(value < root.val)
	            {
	                value = root.val;
	            }                
	            if(root.left != null) 
	            	queue.add(root.left);
	            if(root.right != null) 
	            	queue.add(root.right);
	        }            
	        result.add(value); 
	    }        
	    return result;//return the value set
	}
	
public static void main(String[] args) 
	{
	//constructing a binary tree
	    LargestNodeTree lt = new LargestNodeTree();
	
	    TreeNode node = new TreeNode(5);//add root node
	    node.left = new TreeNode(3);
	    node.right = new TreeNode(1);       
	    node.left.left = new TreeNode(2);
	    node.left.right = new TreeNode(4);
	    node.right.right = new TreeNode(9);
	    node.right.left = new TreeNode(8);
	    node.right.right.right=new TreeNode(2);
	    node.right.right.left =new TreeNode(5);
	    node.right.left.right= new TreeNode(7);
	    node.right.left.left=new TreeNode(6);
	     
	    List<Integer> result = lt.largestValues(node);//storing the result in the list
	    
	    System.out.println(result);//printing the result
	}
 }