package com.DailyAssignment.java;

import java.util.Scanner;

public class TwoSum {
    //function to find the sum of two numbers equal to target
	
    private static int[] findTwoSum(int[] nums, int target) {
        for (int i = 0; i < nums.length; i++)//loop to accept first number
        {
            for (int j = i + 1; j < nums.length; j++)//loop to check the next number
            {
                if (nums[i] + nums[j] == target) //checking if both number's sum is equal to target number
                {
                    return new int[] { i, j };//return the array of indices if the target number is found
                }
            }
        }
        return new int[] {};//else return nothing
    }


    public static void main(String[] args) {
    	System.out.println("Please enter the length of an array:");// taking the length of numbers
        Scanner sc= new Scanner(System.in);//scanner class to accept numbers

        int n = sc.nextInt();//storing value in variable n
        
        int[] nums = new int[n]; //array of n numbers
        System.out.println("Enter Numbers :");
        //loop to accept the numbers
        for(int i = 0; i < n; i++) {
            nums[i] = sc.nextInt();
        }
        System.out.println("Enter the target number: ");
        int target = sc.nextInt();// accepting the target number

        

        int[] indices = findTwoSum(nums, target);//calling function to find the sum of two numbers equal to target

        if (indices.length == 2) {
        	
            System.out.println("Result : "+indices[0] + " " + indices[1]);//printing the resultant indices of the numbers in array
        } else {
            System.out.println("No solution found!");
        }
    }
}