package com.worksheet.java;

public class IdenticalBTree {
	//creating a node
      public static class Node
      {  
      int data;  
      Node left;  
      Node right;  
      //node constructor
      public Node(int data){  
        this.data = data;  //values of the node
        this.left = null;  
        this.right = null;  
      }  
    }  

    public Node root;  //initializing the the root node

    public IdenticalBTree()
    {  
      root = null;  //root has null if there is no node in the tree
    }  
 //function to check id the nodes are identical
    public static boolean areIdenticalTrees(Node root1, Node root2) {  

         
        if(root1 == null && root2 == null)  //if no nodes are there in both trees return true
            return true;      
       
        if(root1 != null  && root2 != null) //checking if both tree has same node using recursion function
        {  

            return ((root1.data == root2.data) &&  
                    (areIdenticalTrees(root1.left, root2.left)) &&  //recursion function to check all the node are identical in both trees
                    (areIdenticalTrees(root1.right, root2.right)));  
        }  
        return false;  //return false if nodes are not equal
    }  


    public static void main(String[] args) {  

      //Adding nodes to the first binary tree  
      IdenticalBTree bt1 = new IdenticalBTree();  //initializing the object of the class
      bt1.root = new Node(1);  //add root node
      bt1.root.left = new Node(2);  //..add left node to the root
      bt1.root.right = new Node(3);// add right node to the root
    //  bt1.root.right = new Node(13);
      bt1.root.left.left = new Node(4);  //same way adding all the nodes
      bt1.root.right.left = new Node(5);  
      bt1.root.right.right = new Node(6);  

      //Adding nodes to the second binary tree  
        IdenticalBTree bt2 = new IdenticalBTree();  
        bt2.root = new Node(1);  
        bt2.root.left = new Node(2);  
        bt2.root.right = new Node(3);  
        bt2.root.left.left = new Node(4);  
        bt2.root.right.left = new Node(5);  
        //bt2.root.right.left = new Node(56);  
        bt2.root.right.right = new Node(6);  

        //Print whether both the trees are identical or not  
         if(areIdenticalTrees(bt1.root, bt2.root))  //passing both the trees as arguments to the function to check
           System.out.println("Both the binary trees are identical");  
       else  
           System.out.println("Both the binary trees are not identical");  
      }  
}