package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class word_break {
	 public static boolean wordBreak(String s, List<String> wordDict) {
	        int len = s.length();//taking the no of charactres from the string
	        boolean [] dp = new boolean[len]; //declaring boolean variable
	        for(int k = 0; k < len; k++)
	        {
	            for(int j = 0; j <= k; j++)//loop to check the substrings from s
	            {
	                if((j == 0 || dp[j-1] == true) && wordDict.contains(s.substring(j, k + 1)))
	                {
	                    dp[k] = true; //retirn true if it can be divided into given substrings
	                    break;
	                }
	            }
	        }
	        return dp[len-1];
	 }
	 public static void main(String[] args) 
	 {
		System.out.println("Enter the String :");//taking the string from the user
		Scanner sc= new Scanner(System.in);
		String s= sc.next();
		List<String> wordDict= new ArrayList<String>();//creating the arralist
		System.out.println("enter the no of words You want to check : ");
		int n=sc.nextInt();
		System.out.println("Enter Dictonary words to check :");
		for(int i=0;i<n;i++)
		{
			wordDict.add(sc.next());
		}
	
		System.out.println(wordDict);//printing the llist elements
		System.out.println(wordBreak(s,wordDict));//function call
	 }
}
