package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Parentheses {
	public static List<String> generateParenthesis(int n)
	{
        List<String> ans=new ArrayList<String>();//declare the arraylist
        findall("(",1,0,ans,n);//function call with parentheses,position ,ans to store the result,and number of combination
        return ans;

    }

     static void findall(String current,int o,int c, List<String> ans,int n)
     {
         if(current.length()==2*n) 
         {
            ans.add(current);
            return;
         }

         if(o<n)
            findall(current+"(",o+1,c,ans,n);
        if(c<o)
            findall(current+")",o,c+1,ans,n);
     }
public static void main(String[] args) {
	System.out.println("Enter the number of parentheses combination : ");//taking the inputs from user
	Scanner sc= new Scanner (System.in);
	int n=sc.nextInt();
	System.out.println(generateParenthesis(n));//function call
}
}
