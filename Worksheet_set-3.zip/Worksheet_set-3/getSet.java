package com.java;

import java.util.Scanner;

class Example{
	private int id;
	private String name;
	public void setId(int s_id)
	{
		this.id=s_id;
	}
	public  void setNname(String s_name)
	{
		this.name=s_name;
	}
	public int getId()
	{
		return id;
	}
	public String getName()
	{
		return name;
	}
	
}
public class getSet {
public static void main(String[] args) {
	String Name;
	int Id;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the name : ");
	Name= sc.nextLine();
	System.out.println("Enter the ID : ");
	Id=sc.nextInt();
	Example e=new Example();
	e.setId(Id);
	e.setNname(Name);
	
	
	System.out.println("Name : "+e.getName()+"  "+"Id: "+e.getId());
	
	
}

