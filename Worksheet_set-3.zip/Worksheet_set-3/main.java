package com.java;

import java.util.Scanner;

public class Addition{
	
	public static int addTwoInt(int a,int b)
	{
		return a+b;
	}

}

public class main {
	public static void main(String[] args) {
		int n1,n2;
		int sum=0;
		System.out.println("Enter two numbers for addition: ");
		System.out.println("number 1: ");
		Scanner sc= new Scanner(System.in);
		n1=sc.nextInt();
		System.out.println("number 2: ");
		n2=sc.nextInt();
		Addition add= new Addition();
		sum = add.addTwoInt(n1, n2);
		System.out.println("Sum of two numbers : "+sum);
	}

}
