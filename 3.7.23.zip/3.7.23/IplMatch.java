package com.DailyAssignment.java;

import java.util.ArrayList;
import java.util.Scanner;

public class IplMatch {
	
	static int Max(int[] arr, int i,int j) //function to find max element from  sub array
{
    int max=arr[i];
    for(int k=i+1;k<=j;k++)
    {
        max=Math.max(max,arr[k]);
    }
    return max; //return max element
}
static ArrayList<Integer> max_of_subarrays(int arr[], int n, int k)
{
    
    ArrayList<Integer>list=new ArrayList<>(); 
    int max=arr[0]; //declaring first element as maximum
    for(int i=0;i<k;i++)
    {
        max=Math.max(max,arr[i]);
    }
    list.add(max);
    //loop to find the sub arrays of k size
    for(int i=1;i<=n-k;i++)
    {
        if(max==arr[i-1])
        {
            max=Max(arr, i, i+k-1);//call MAx function to find max eklement
        }
        else
        {
            max=Math.max(max, arr[i+k-1]);
        }
        list.add(max); //addd maximum element to list
    }
    return list;
}
public static void main(String[] args) 
{
	
	System.out.println("Enter no of players(n) :"); //taking the input from user
	Scanner sc= new Scanner(System.in);
	int n= sc.nextInt();
	System.out.println("Enter no sub list(K) : ");
	int k=sc.nextInt();
	System.out.println("Enter the array elements :");
	int[] arr=new int[n];
	for(int i=0;i<n;i++) //loop to take the array elements
	{
		arr[i]=sc.nextInt();
	}
	ArrayList<Integer>list=new ArrayList<>(); //declare arraylist variable
	list=max_of_subarrays(arr,n,k);//function call
	System.out.println("result : "+list); //print the result
}
}




