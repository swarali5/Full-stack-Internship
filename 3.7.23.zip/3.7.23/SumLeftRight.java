package com.DailyAssignment.java;

import java.util.Scanner;

public class SumLeftRight {
	static String equilibrium(int arr[], int n) {
        int sum=0;
        for(int i=0;i<n;i++){
            sum+=arr[i];//calculating sum of elements
        }
        int sum1=0;
        for(int i=0;i<n;i++)
        {
            if(i!=0)
            	sum1+=arr[i-1]; //sum of elements from 2nd position
                sum-=arr[i]; //decrease the element from sum
            if(sum1==sum) //compare the sums
            	return "YES";//return yes if matches
        }
        return "NO";
    }
	public static void main(String[] args) {
		//taking the input from user
		System.out.println("Enter the lenghth of an array :");
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		System.out.println("Enter the array elements :");
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Result : "+equilibrium(arr,n));//function call
	}
}
